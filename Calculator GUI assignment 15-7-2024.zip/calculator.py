import addition
import subtraction
import multiplication
import division


def calculator():
    num1 = float(input("Enter the first number: "))
    num2 = float(input("Enter the second number: "))
    operator = input("Enter the operator (+, -, *, /): ")

    if operator == "+":
        result = addition.add(num1, num2)
    elif operator == "-":
        result = subtraction.subtract(num1, num2)
    elif operator == "*":
        result = multiplication.multiply(num1, num2)
    elif operator == "/":
        result = division.divide(num1, num2)
    else:
        result = "Error: Invalid operator"

    print("Result: ", result)

    response = input("Do you want to quit the calculator? (Y/N): ")
    if response.upper() == "Y":
        print("Goodbye!")
    else:
        calculator()


calculator()
